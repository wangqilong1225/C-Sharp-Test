﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using XMLSerializer.Model;

namespace XMLSerializer
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string xml = "<GetMyFeesEstimateResponse xmlns=\"http://mws.amazonservices.com/schema/Products/2011-10-01\">  <GetMyFeesEstimateResult>    <FeesEstimateResultList>      <FeesEstimateResult>        <FeesEstimate>          <TotalFeesEstimate>            <CurrencyCode>AUD</CurrencyCode>            <Amount>29.96</Amount>          </TotalFeesEstimate>          <TimeOfFeesEstimation>2019-04-12T07:07:09.454Z</TimeOfFeesEstimation>          <FeeDetailList>            <FeeDetail>              <FeeAmount>                <CurrencyCode>AUD</CurrencyCode>                <Amount>29.96</Amount>              </FeeAmount>              <FinalFee>                <CurrencyCode>AUD</CurrencyCode>                <Amount>29.96</Amount>              </FinalFee>              <FeePromotion>                <CurrencyCode>AUD</CurrencyCode>                <Amount>0.00</Amount>              </FeePromotion>              <FeeType>ReferralFee</FeeType>            </FeeDetail>            <FeeDetail>              <FeeAmount>                <CurrencyCode>AUD</CurrencyCode>                <Amount>0.00</Amount>              </FeeAmount>              <FinalFee>                <CurrencyCode>AUD</CurrencyCode>                <Amount>0.00</Amount>              </FinalFee>              <FeePromotion>                <CurrencyCode>AUD</CurrencyCode>                <Amount>0.00</Amount>              </FeePromotion>              <FeeType>VariableClosingFee</FeeType>            </FeeDetail>          </FeeDetailList>        </FeesEstimate>        <FeesEstimateIdentifier>          <MarketplaceId>A39IBJ37TRP1C6</MarketplaceId>          <IdType>SellerSKU</IdType>          <SellerId>A2B17B5KJCUVQ8</SellerId>          <SellerInputIdentifier>request1</SellerInputIdentifier>          <IsAmazonFulfilled>false</IsAmazonFulfilled>          <IdValue>AC13290</IdValue>          <PriceToEstimateFees>            <ListingPrice>              <CurrencyCode>AUD</CurrencyCode>              <Amount>499.37</Amount>            </ListingPrice>            <Shipping>              <CurrencyCode>AUD</CurrencyCode>              <Amount>0</Amount>            </Shipping>            <Points>              <PointsMonetaryValue>                <CurrencyCode>AUD</CurrencyCode>                <Amount>0</Amount>              </PointsMonetaryValue>              <PointsNumber>0</PointsNumber>            </Points>          </PriceToEstimateFees>        </FeesEstimateIdentifier>        <Status>Success</Status>      </FeesEstimateResult>    </FeesEstimateResultList>  </GetMyFeesEstimateResult>  <ResponseMetadata>    <RequestId>ab0b5076-06b3-4653-b4f6-f9ee4c39a0e1</RequestId>  </ResponseMetadata></GetMyFeesEstimateResponse>";
         
            RequestResponse RequestResponse= DeserializeXml(typeof(RequestResponse), xml) as RequestResponse;
        }
        
        public static object DeserializeXml(Type type, string xml)
        {
            using (StringReader sr = new StringReader(xml))
            {
                XmlSerializer desXml = new XmlSerializer(type);
                return desXml.Deserialize(sr);
            }
        }

    }
}
