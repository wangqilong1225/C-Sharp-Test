﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XMLSerializer.Model
{
    [XmlRoot(Namespace = "http://mws.amazonservices.com/schema/Products/2011-10-01", ElementName = "GetMyFeesEstimateResponse", IsNullable = false)]
    public class RequestResponse
    {
        [XmlElement(ElementName = "GetMyFeesEstimateResult")]
        public GetMyFeesEstimateResult getMyFeesEstimateResult;
    }

    public class GetMyFeesEstimateResult
    {
        [XmlElement(ElementName = "FeesEstimateResultList")]
        public FeesEstimateResultList feesEstimateResultList;       
    }

    public class FeesEstimateResultList
    {
        [XmlElement(ElementName = "FeesEstimateResult")]
        public List<FeesEstimateResult> feesEstimateResult;
    }

    public class FeesEstimateResult
    {
        [XmlElement(ElementName = "FeesEstimate")]
        public FeesEstimate feesEstimate;
        [XmlElement(ElementName = "FeesEstimateIdentifier")]
        public FeesEstimateIdentifier feesEstimateIdentifier;
        [XmlElement(ElementName = "Status")]
        public string Status;
    }
    
    public class FeesEstimate
    {
        [XmlElement(ElementName = "TotalFeesEstimate")]
        public TotalFeesEstimate totalFeesEstimate;
    }

    public class TotalFeesEstimate
    {
        [XmlElement(ElementName = "Amount")]
        public decimal Fee;
    }

    public class FeesEstimateIdentifier
    {
        [XmlElement(ElementName = "IdValue")]
        public string SKU;
        [XmlElement(ElementName = "PriceToEstimateFees")]
        public PriceToEstimateFees priceToEstimateFees;
    }

    public class PriceToEstimateFees
    {
        [XmlElement(ElementName = "ListingPrice")]
        public ListingPrice listingPrice;
    }

    public class ListingPrice
    {
        [XmlElement(ElementName = "Amount")]
        public decimal Price;
    }
}
